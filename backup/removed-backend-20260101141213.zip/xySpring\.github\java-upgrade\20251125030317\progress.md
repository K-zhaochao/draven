# Upgrade Progress

  ### ✅ Generate Upgrade Plan [View Log](logs\1.generatePlan.log)

  ### ✅ Confirm Upgrade Plan [View Log](logs\2.confirmPlan.log)

  ### ❗ Setup Development Environment [View Log](logs\3.setupEnvironment.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - terminated
  
  
  - ###
    ### ✅ Install JDK 21
  </details>

  ### ✅ Setup Development Environment [View Log](logs\4.setupEnvironment.log)

  ### ✅ PreCheck [View Log](logs\5.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Precheck - Build project [View Log](logs\5.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  
    ### ✅ Precheck - Validate CVEs [View Log](logs\5.2.precheck-validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### CVE issues
    </details>
  
    ### ❗ Precheck - Run tests [View Log](logs\5.3.precheck-runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Errors
    Failed to run tests with errors: [ERROR] Failed to execute goal org.apache.maven.plugins:maven-surefire-plugin:3.5.4:test (default-test) on project xySpring: Failed to collect dependencies at org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: Failed to read artifact descriptor for org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: The following artifacts could not be resolved: org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 (absent): Could not transfer artifact org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 from/to central (https://repo.maven.apache.org/maven2): Connect to repo.maven.apache.org:443 [repo.maven.apache.org/198.18.0.27] failed: Connect timed out -\> [Help 1] [ERROR]  [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. [ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]  [ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
      ```
      Error: Failed to run tests with errors:
      [ERROR] Failed to execute goal org.apache.maven.plugins:maven-surefire-plugin:3.5.4:test (default-test) on project xySpring: Failed to collect dependencies at org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: Failed to read artifact descriptor for org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: The following artifacts could not be resolved: org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 (absent): Could not transfer artifact org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 from/to central (https://repo.maven.apache.org/maven2): Connect to repo.maven.apache.org:443 [repo.maven.apache.org/198.18.0.27] failed: Connect timed out -\> [Help 1]
      [ERROR] 
      [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch.
      [ERROR] Re-run Maven using the -X switch to enable full debug logging.
      [ERROR] 
      [ERROR] For more information about the errors and possible solutions, please read the following articles:
      [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
          at zne.test (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:531:2629)
          at qea (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:944:224)
          at mx.doInvoke (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:938:838)
          at mx.invoke (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:592:11180)
          at X4e.invoke (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:1370:172)
          at tQ.$invokeTool (file:///d:/6.SoftWare/1.IDE/VisualStudioCode/Microsoft%20VS%20Code/resources/app/out/vs/workbench/api/node/extensionHostProcess.js:192:3195)
      ```
    </details>
  </details>

  ### ✅ Upgrade project to use `Java 21`
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ❗ Upgrade using OpenRewrite [View Log](logs\6.1.upgradeProjectUsingOpenRewrite.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Recipes
    - [org.openrewrite.java.migrate.UpgradeToJava21](https://docs.openrewrite.org/recipes/java/migrate/UpgradeToJava21)
    
    #### Errors
    Failed to run command: "mvn -B org.openrewrite.maven:rewrite-maven-plugin:5.47.3:run -Drewrite.activeRecipes=org.openrewrite.java.migrate.UpgradeToJava21 -Drewrite.recipeArtifactCoordinates=org.openrewrite.recipe:rewrite-migrate-java:2.31.1" with error code 1 
      ```
      Error: Failed to run command: "mvn -B org.openrewrite.maven:rewrite-maven-plugin:5.47.3:run -Drewrite.activeRecipes=org.openrewrite.java.migrate.UpgradeToJava21 -Drewrite.recipeArtifactCoordinates=org.openrewrite.recipe:rewrite-migrate-java:2.31.1" with error code 1
      
          at I.run (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:446:1015)
          at processTicksAndRejections (node:internal/process/task\_queues:105:5)
          at zne.runOpenRewriteRecipes (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:532:1537)
          at dx.doInvoke (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:923:7)
          at dx.invoke (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:592:11180)
          at X4e.invoke (c:\Users\ASUS\.vscode\extensions\vscjava.vscode-java-upgrade-1.8.1\dist\extension.js:1370:172)
          at tQ.$invokeTool (file:///d:/6.SoftWare/1.IDE/VisualStudioCode/Microsoft%20VS%20Code/resources/app/out/vs/workbench/api/node/extensionHostProcess.js:192:3195)
      ```
    </details>
  
    ### ✅ Upgrade using Agent [View Log](logs\6.2.upgradeProjectUsingAgent.log)
    1 file changed, 1 insertion(+), 1 deletion(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Upgrade Java version to 21 in `pom.xml`
      - Change `<java.version>` property from 17 to 21.
    </details>
  
    ### ✅ Build Project [View Log](logs\6.3.buildProject.log)
    Build result: 100% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  </details>

  ### ⏳ Validate & Fix ...Running
  
  - ###
    ### ✅ Validate CVEs [View Log](logs\7.1.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - java:*:21
    </details>
  
    ### ✅ Validate Code Behavior Changes [View Log](logs\7.2.validateBehaviorChanges.log)
  
    ### ❗ Run Tests [View Log](logs\7.3.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Errors
    - Failed running tests: Error: Failed to run tests with errors: [ERROR] Failed to execute goal org.apache.maven.plugins:maven-surefire-plugin:3.5.4:test (default-test) on project xySpring: Failed to collect dependencies at org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: Failed to read artifact descriptor for org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: The following artifacts could not be resolved: org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 (absent): Could not transfer artifact org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 from/to central (https://repo.maven.apache.org/maven2): Connect to repo.maven.apache.org:443 [repo.maven.apache.org/198.18.0.27] failed: Connect timed out -\> [Help 1] [ERROR]  [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. [ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]  [ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
    </details>
  
    ### ❗ Run Tests [View Log](logs\7.4.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Errors
    - Failed running tests: Error: Failed to run tests with errors: [ERROR] Failed to execute goal org.apache.maven.plugins:maven-surefire-plugin:3.5.4:test (default-test) on project xySpring: Failed to collect dependencies at org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: Failed to read artifact descriptor for org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: The following artifacts could not be resolved: org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 (absent): Could not transfer artifact org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 from/to central (https://repo.maven.apache.org/maven2): Connect to repo.maven.apache.org:443 [repo.maven.apache.org/198.18.0.27] failed: Connect timed out -\> [Help 1] [ERROR]  [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. [ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]  [ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
    </details>
  
    ### ❗ Run Tests [View Log](logs\7.5.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Errors
    - Failed running tests: Error: Failed to run tests with errors: [ERROR] Failed to execute goal org.apache.maven.plugins:maven-surefire-plugin:3.5.4:test (default-test) on project xySpring: Failed to collect dependencies at org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: Failed to read artifact descriptor for org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: The following artifacts could not be resolved: org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 (absent): Could not transfer artifact org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 from/to central (https://repo.maven.apache.org/maven2): Connect to repo.maven.apache.org:443 [repo.maven.apache.org/198.18.0.27] failed: Connect timed out -\> [Help 1] [ERROR]  [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. [ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]  [ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
    </details>

  ### ❗ Summarize Upgrade [View Log](logs\8.summarizeUpgrade.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to run tests with errors: [ERROR] Failed to execute goal org.apache.maven.plugins:maven-surefire-plugin:3.5.4:test (default-test) on project xySpring: Failed to collect dependencies at org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: Failed to read artifact descriptor for org.apache.maven.surefire:surefire-junit-platform:jar:3.5.4: The following artifacts could not be resolved: org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 (absent): Could not transfer artifact org.apache.maven.surefire:surefire-junit-platform:pom:3.5.4 from/to central (https://repo.maven.apache.org/maven2): Connect to repo.maven.apache.org:443 [repo.maven.apache.org/198.18.0.27] failed: Connect timed out -\> [Help 1] [ERROR]  [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. [ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]  [ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoExecutionException
  </details>